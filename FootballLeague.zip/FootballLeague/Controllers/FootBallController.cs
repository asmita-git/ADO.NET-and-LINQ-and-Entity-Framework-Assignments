﻿using FootballLeague.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace FootballLeague.Controllers
{
    public class FootBallController : Controller
    {
        FootBallEntities1 db = new FootBallEntities1();
        // GET: Default
        public ActionResult Index()
        {
            var data = db.FootBallLeagues.ToList();
            return View(data);
        }

        public ActionResult Create()
        {
            
            return View();
        }
        [HttpPost]
        public ActionResult Create(FootBallLeague F)
        {

            if(ModelState.IsValid==true)
            {

            }
            db.FootBallLeagues.Add(F);
              int a=  db.SaveChanges();
            if(a>0)
            {
                TempData["InsertaMessage"] = "<script> ale('Inserted !!')</script>";
                return RedirectToAction("Index");

            }
            else
            {
                TempData["InsertaMessage"] = "<script> ale(' Not Inserted !!')</script>";
            }

            return View();
        }
        public ActionResult Edit( int MatchID)
        {
            var row = db.FootBallLeagues.Where(model => model.MatchID == MatchID).FirstOrDefault();

            return View(row);
        }
        [HttpPost]
        public ActionResult Edit(FootBallLeague F)
        {
            if (ModelState.IsValid == true)
            {
                db.Entry(F).State = EntityState.Modified;
                int a = db.SaveChanges();
                if (a > 0)
                {
                    TempData["UpdatedaMessage"] = "<script> ale('Inserted !!')</script>";
                    return RedirectToAction("Index");

                }
                else
                {
                    TempData["UpdatedaMessage"] = "<script> ale(' Not Updated  !!')</script>";
                }

            }

            return View();
        }

        public ActionResult Delete( int MatchID)
        {
            var DeletedRow = db.FootBallLeagues.Where(model => model.MatchID == MatchID).FirstOrDefault();

            return View(DeletedRow);

            //return View();
        }

        [HttpPost]
        public ActionResult Delete(FootBallLeague F)
        {
            if (ModelState.IsValid == true)
            {
                db.Entry(F).State = EntityState.Deleted;
                int a = db.SaveChanges();
                if (a > 0)
                {
                    TempData["DeleteMessage"] = "<script> ale('Deleted !!')</script>";
                    return RedirectToAction("Index");

                }
                else
                {
                    TempData["DeleteMessage"] = "<script> ale(' Not Deleted  !!')</script>";
                }

            }

            return View();
        }

        public ActionResult Details(int MatchID)
        {
            var DeletedRow = db.FootBallLeagues.Where(model => model.MatchID == MatchID).FirstOrDefault();

            return View(DeletedRow);

            
        }

    }
}